package com.example.performancemeasurement;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class OpeningPageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opening_page);
    }
}
