package com.example.performancemeasurement;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TipsAndTricksActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tips_and_tricks);
    }
}
